﻿using System;
using System.Windows.Forms;

namespace TheEye
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            // Устанавливаем поддержку визуальных компонентов
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Запускаем форму MainForm
            Application.Run(new MainForm());
        }
    }
}
