﻿using System;
using System.Media;
using System.Windows.Forms;

namespace TheEye
{
    public partial class MainForm : Form
    {
        private SoundPlayer soundPlayer;
        private bool isMoving = false;  // Объявление переменной isMoving только один раз

        public MainForm()
        {
            InitializeComponent();

            // Устанавливаем размеры окна
            this.Width = 300;
            this.Height = 300;

            // Делаем окно всегда поверх всех окон
            this.TopMost = true;

            // Убираем возможность изменения размера
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // Центрируем окно
            this.StartPosition = FormStartPosition.CenterScreen;

            // Устанавливаем чёрный фон для формы
            this.BackColor = System.Drawing.Color.Black;

            // Создаём и настраиваем PictureBox для GIF
            PictureBox pictureBox = new PictureBox();
            int originalWidth = TheEye.Properties.Resources.TheEye.Width;
            int originalHeight = TheEye.Properties.Resources.TheEye.Height;

            // Уменьшаем размер гифки на 25%
            pictureBox.Size = new System.Drawing.Size((int)(originalWidth * 0.75), (int)(originalHeight * 0.75));

            // Смещаем гифку немного вверх и влево
            pictureBox.Location = new System.Drawing.Point((this.Width - pictureBox.Width) / 2 - 10, (this.Height - pictureBox.Height) / 2 - 20);
            pictureBox.Image = TheEye.Properties.Resources.TheEye;
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom; // Сохраняем пропорции

            // Добавляем PictureBox на форму
            this.Controls.Add(pictureBox);

            // Инициализация SoundPlayer
            soundPlayer = new SoundPlayer(Properties.Resources.Main);
            soundPlayer.PlayLooping();  // Запуск воспроизведения по кругу
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            MessageBox.Show("DON'T DARE YOU CLOSE ME!!!!", " ", MessageBoxButtons.OK, MessageBoxIcon.Error);  // Используем стандартный MsgBox
            e.Cancel = true;
        }

        protected override void OnMove(EventArgs e)
        {
            if (!isMoving)
            {
                isMoving = true;
            }
            else
            {
                MessageBox.Show("DON'T DARE YOU MOVE ME!!!", " ", MessageBoxButtons.OK, MessageBoxIcon.Error);  // Используем стандартный MsgBox
            }
            base.OnMove(e);
        }
    }
}
